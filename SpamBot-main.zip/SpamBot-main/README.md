
<!--This Bot is Made By Gladitors Project-->
<p align="center">
  <img src="spambot/resources/Gladiators.jpeg" alt="Logo">
</p>

### 🚀 Gʟᴀᴅɪᴀᴛᴏʀs SᴘᴀᴍBᴏᴛ

  <a href="https://github.com/Gladiators-Projects"><img alt="Website" src="https://img.shields.io/badge/Gladiators-Projects-blue"></a>
  [![Stars](https://img.shields.io/github/stars/Gladiators-Projects/Spambot?style=social)](https://github.com/Gladiators-Projects/SpamBot/stargazers)
  [![Forks](https://img.shields.io/github/forks/Gladiators-Projects/Spambot?style=social)](https://github.com/Gladiators-Projects/SpamBot/fork)

### Dᴇᴘʟᴏʏ Tᴏ Hᴇʀᴏᴋᴜ
  
  [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Gladiators-Projects/spambot)

### 🛠️ Lᴀɴɢᴜᴀɢᴇs Aɴᴅ Tᴏᴏʟs

  ![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
  ![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)
  ![Heroku](https://img.shields.io/badge/Heroku-430098?style=for-the-badge&logo=heroku&logoColor=white)

## 🗒️ Nᴇᴄᴇssᴀʀʏ Vᴀʀɪᴀʙʟᴇs

☞ `API_ID` - Get your API_ID from [my.telegram.org](https://my.telegram.org/)<br>
☞ `API_HASH` - Get your API_HASH from [my.telegram.org](https://my.telegram.org/)<br>
☞ `BOT_TOKEN` - Your Bot-Token get that from BotFather!!<br>
☞ `LOGS` - Your logger group id get that using any other bot!!<br>
☞ `BOT_ID` - Your bot id get that using any other bot!!<br>
☞ `OWNER_ID` - User id of the master get that using any other bot!!<br>
☞ `MASTER_NAME` - Name of the master, whivh will be displayed in bots dm!!


## 📌 Cʀᴇᴅɪᴛs 
* [![TeamGladiators-Devs](https://img.shields.io/static/v1?label=TeamGladiators&message=Devs&color=critical)](https://t.me/Gladiators_Devs)
* [Yone-Bot](https://github.com/noob-kittu/YoneRobot) For Base
* [Yukki-Bot](https://github.com/YukkiBot/YukkiMultiSpamBot) For Curses.
* [Ultroid](https://github.com/TeamUltroid/Ultroid) For Some Plugins


```
If you are taking code from this repository without a fork, then atleast give credits to our hardwork & star to this repo. ❤️
```
