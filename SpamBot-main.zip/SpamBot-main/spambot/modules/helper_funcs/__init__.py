"""
Credits To:
t.me/TeamGladiators for whole
t.me/TeamUltroid for modules
t.me/Yone_Support for base
"""
